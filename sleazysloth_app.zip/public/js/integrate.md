
if max_supply > 800:

    Check if public mint is true:
        then allow public+whtielist mitning

    if not:
        only allow whitelist minting

    in background:
        fetch the getFMC() to check hwo many minted

    now costing:
        when the user clciked 
        minus the mint_count from the getFMC() and send the cost as per that

